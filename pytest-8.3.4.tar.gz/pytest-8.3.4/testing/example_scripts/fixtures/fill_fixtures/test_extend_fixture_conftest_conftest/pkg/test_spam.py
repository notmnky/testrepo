# mypy: allow-untyped-defs
from __future__ import annotations


def test_spam(spam):
    assert spam == "spamspam"
