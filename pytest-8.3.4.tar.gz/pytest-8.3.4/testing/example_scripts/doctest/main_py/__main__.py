# mypy: allow-untyped-defs
from __future__ import annotations


def test_this_is_ignored():
    assert True
