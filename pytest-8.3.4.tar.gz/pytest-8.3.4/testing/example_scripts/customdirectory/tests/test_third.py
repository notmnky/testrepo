# mypy: allow-untyped-defs
# content of test_third.py
from __future__ import annotations


def test_3():
    pass
