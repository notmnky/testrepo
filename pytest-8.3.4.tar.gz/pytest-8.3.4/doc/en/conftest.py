from __future__ import annotations


collect_ignore = ["conf.py"]
