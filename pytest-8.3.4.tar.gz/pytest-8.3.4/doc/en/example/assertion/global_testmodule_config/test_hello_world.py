from __future__ import annotations


hello = "world"


def test_func():
    pass
