from __future__ import annotations


collect_ignore = ["nonpython", "customdirectory"]
