# content of test_second.py
from __future__ import annotations


def test_2():
    pass
