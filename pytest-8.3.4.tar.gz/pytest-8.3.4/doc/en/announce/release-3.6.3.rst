pytest-3.6.3
=======================================

pytest 3.6.3 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* AdamEr8
* Anthony Sottile
* Bruno Oliveira
* Jean-Paul Calderone
* Jon Dufresne
* Marcelo Duarte Trevisani
* Ondřej Súkup
* Ronny Pfannschmidt
* T.E.A de Souza
* Victor Maryama


Happy testing,
The pytest Development Team
